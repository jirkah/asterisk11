//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by PocketPJ.rc
//
#define IDD_POCKETPJ_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_ONLINE                      131
#define IDI_OFFLINE                     132
#define IDI_INVISIBLE                   133
#define IDB_ONLINE                      135
#define IDB_OFFLINE                     136
#define IDB_INVISIBLE                   137
#define IDB_ACTION                      138
#define IDR_ACC_MENU                    139
#define IDR_URI_MENU                    140
#define IDD_SETTING                     141
#define IDD_POPUP                       143
#define IDB_BLANK                       144
#define IDC_BTN_ACC                     1006
#define IDC_BTN_ACTION                  1007
#define IDC_ACC_ID                      1008
#define IDC_BUDDY_LIST                  1009
#define IDC_URL                         1010
#define IDC_DOMAIN                      1011
#define IDC_USER                        1012
#define IDC_PASSWD                      1013
#define IDC_STUN                        1014
#define IDC_STUN_SRV                    1015
#define IDC_ICE                         1016
#define IDC_SRTP                        1017
#define IDC_TITLE1                      1017
#define IDC_PUBLISH                     1018
#define IDC_TITLE2                      1018
#define IDC_DNS                         1019
#define IDC_TITLE3                      1020
#define IDC_ECHO_SUPPRESS               1020
#define IDC_BUTTON1                     1021
#define IDC_EC_TAIL                     1021
#define IDC_BUTTON2                     1022
#define IDC_VAD                         1022
#define IDC_TCP                         1023
#define IDC_CODECS                      1024
#define IDC_AA                          1025
#define IDS_CAP_ONLINE                  32772
#define IDS_CAP_OFFLINE                 32774
#define IDS_CAP_INVISIBLE               32776
#define IDC_ONLINE                      32777
#define IDC_ACC_ONLINE                  32777
#define IDS_CAP_MENUITEM32783           32784
#define IDC_MENU1                       32785
#define IDS_CAP_MENUITEM32786           32787
#define IDC_SETTINGS                    32788
#define IDC_ACC_SETTINGS                32788
#define IDC_MENU2                       32789
#define IDS_CAP_MENUITEM32790           32791
#define IDC_URI_CALL                    32792
#define IDC_URI_ADD_BUDDY               32793
#define ID_URI_DEL_BUDDY                32794
#define IDC_URI_DEL_BUDDY               32794
#define IDC_ACC_INVISIBLE               32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
